package com.example.appcadastro;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class CadastroActivity2 extends AppCompatActivity {
    EditText txtNome, txtTurma;
    Button btnCadastrar;
    SQLiteDatabase bancoPaises;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro2);

        txtNome = (EditText) findViewById(R.id.txtNome);
        txtTurma = (EditText) findViewById(R.id.txtTurma);
        btnCadastrar = (Button) findViewById(R.id.btnCadastrar);

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cadastrar();
            }
        });
    }

    public void cadastrar(){
        if(!TextUtils.isEmpty(txtNome.getText().toString())){
            try{
                bancoPaises = openOrCreateDatabase("aluno", MODE_PRIVATE, null);
                String sql = "INSERT INTO aluno (nome,turma) VALUES (?,?)";
                SQLiteStatement stmt = bancoPaises.compileStatement(sql);
                stmt.bindString(1,txtNome.getText().toString());
                stmt.bindString(2,txtTurma.getText().toString());
                stmt.executeInsert();
                bancoPaises.close();
                finish();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}