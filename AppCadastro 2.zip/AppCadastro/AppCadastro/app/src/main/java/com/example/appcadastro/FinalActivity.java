package com.example.appcadastro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class FinalActivity extends AppCompatActivity {

    Button btnExcluir;
    private SQLiteDatabase bancoDados, bancoPaises;
    Intent intent;
    String email;
    ListView listView;
    FloatingActionButton btnCadastro;
    public ArrayList<Integer> arrayIds;
    Integer idSelecionado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final);

        intent = getIntent();
        email = intent.getStringExtra("email");

        btnExcluir = (Button) findViewById(R.id.btnExcluir);

        carregarDados();

        btnExcluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                excluirConta();
            }
        });

        listView = (ListView) findViewById(R.id.listView);
        btnCadastro = (FloatingActionButton) findViewById(R.id.btnCadastro);

        btnCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirTelaCadastro();
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                idSelecionado = arrayIds.get(i);
                deletar();
                return false;
            }
        });

        criarBancoDados();
        listarDados();

    }

    @Override
    protected void onResume(){
        super.onResume();
        listarDados();
    }

    public void excluirConta(){
        try{
            bancoDados = openOrCreateDatabase("cadastro", MODE_PRIVATE, null);
            String sql = "DELETE FROM usuario WHERE email = ?";
            SQLiteStatement stmt = bancoDados.compileStatement(sql);
            stmt.bindString(1,email);
            stmt.executeUpdateDelete();
            bancoDados.close();
            abrirTelaPrincipal();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void carregarDados(){
        try {
            bancoDados = openOrCreateDatabase("cadastro", MODE_PRIVATE, null);
            Cursor cursor = bancoDados.rawQuery("SELECT * FROM usuario WHERE email = '" + email + "'", null);
            cursor.moveToFirst();

        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public void abrirTelaPrincipal(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void criarBancoDados(){
        try {
            bancoPaises = openOrCreateDatabase("aluno", MODE_PRIVATE, null);
            bancoPaises.execSQL("CREATE TABLE IF NOT EXISTS aluno(" +
                    "   id INTEGER PRIMARY KEY AUTOINCREMENT" +
                    " , nome VARCHAR" +
                    " , turma VARCHAR)");
            bancoPaises.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void listarDados(){
        try {

            bancoPaises = openOrCreateDatabase("aluno", MODE_PRIVATE, null);
            Cursor meuCursor = bancoPaises.rawQuery("SELECT id, nome, turma FROM aluno", null);
            ArrayList<String> linhas = new ArrayList<String>();
            ArrayAdapter meuAdapter = new ArrayAdapter<String>(
                    this,
                    android.R.layout.simple_list_item_1,
                    android.R.id.text1,
                    linhas
            );
            listView.setAdapter(meuAdapter);
            arrayIds = new ArrayList<>();
            meuCursor.moveToFirst();
            do {
                linhas.add(meuCursor.getString(0) + " - " + meuCursor.getString(1));
                arrayIds.add(meuCursor.getInt(0));
            } while(meuCursor.moveToNext());

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void abrirTelaCadastro(){
        Intent intent = new Intent(this,CadastroActivity2.class);
        startActivity(intent);
    }

    public void deletar(){
        try{
            bancoPaises = openOrCreateDatabase("aluno", MODE_PRIVATE, null);
            String sql = "DELETE FROM aluno WHERE id =?";
            SQLiteStatement stmt = bancoPaises.compileStatement(sql);
            stmt.bindLong(1, idSelecionado);
            stmt.executeUpdateDelete();
            listarDados();
            bancoPaises.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

}