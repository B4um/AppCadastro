package com.example.appcadastro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText txtEmail, txtSenha;
    Button btnLogin, btnCadastrar;
    SQLiteDatabase bancoDados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtEmail = (EditText) findViewById(R.id.txtEmail);
        txtSenha = (EditText) findViewById(R.id.txtSenha);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnCadastrar = (Button) findViewById(R.id.btnCadastrar);

        criarBancoDados();

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirTelaCadastro();
            }
        });
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                verificarCadastro();
            }
        });
    }

    public void criarBancoDados() {
        try {
            bancoDados = openOrCreateDatabase("cadastro", MODE_PRIVATE, null);
            bancoDados.execSQL("CREATE TABLE IF NOT EXISTS usuario(" +
                    " email VARCHAR PRIMARY KEY" +
                    " ,senha  VARCHAR)");
            bancoDados.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void abrirTelaCadastro() {
        Intent intent = new Intent(this, CadastroActivity.class);
        startActivity(intent);
    }

    public void verificarCadastro() {
        if (!TextUtils.isEmpty(txtEmail.getText().toString()) && !TextUtils.isEmpty(txtSenha.getText().toString())) {
            try {
                bancoDados = openOrCreateDatabase("cadastro", MODE_PRIVATE, null);

                Cursor meuCursor = bancoDados.rawQuery("SELECT email FROM usuario " +
                        "WHERE email = '" + txtEmail.getText().toString() + "' " +
                        "AND senha = '" + txtSenha.getText().toString() + "' ", null);
                meuCursor.moveToFirst();
                if (meuCursor.getCount() > 0) {
                    abrirTelaFinal();
                } else {
                    Toast.makeText(this, "Nao existe esta conta", Toast.LENGTH_SHORT).show();
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    public void abrirTelaFinal() {
        Intent intent = new Intent(this, FinalActivity.class);
        intent.putExtra("email", txtEmail.getText().toString());
        startActivity(intent);
    }
}