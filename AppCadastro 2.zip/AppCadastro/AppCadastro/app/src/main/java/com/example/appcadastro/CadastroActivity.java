package com.example.appcadastro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CadastroActivity extends AppCompatActivity {

    EditText txtEmailC, txtSenhaC;
    Button btnCadastrarConta;
    SQLiteDatabase bancoDados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        txtEmailC = (EditText) findViewById(R.id.txtNome) ;
        txtSenhaC = (EditText) findViewById(R.id.txtSenhaC);
        btnCadastrarConta = (Button) findViewById(R.id.btnCadastrarConta);

        btnCadastrarConta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cadastrarUsuario();
            }
        });

    }

    public void cadastrarUsuario(){
        if(!TextUtils.isEmpty(txtEmailC.getText().toString()) && !TextUtils.isEmpty(txtSenhaC.getText().toString())){
            try{
                bancoDados = openOrCreateDatabase("cadastro", MODE_PRIVATE, null);
                String sql = "INSERT INTO usuario (email,senha) VALUES (?,?)";
                SQLiteStatement stmt = bancoDados.compileStatement(sql);
                stmt.bindString(1,txtEmailC.getText().toString());
                stmt.bindString(2,txtSenhaC.getText().toString());
                stmt.executeInsert();
                bancoDados.close();
                abrirTelaPrincipal();
                finish();
            }catch (Exception e){
                e.printStackTrace();
            }
        }else{
            Toast.makeText(this, "Insira os dados corretamente", Toast.LENGTH_SHORT).show();
        }
    }

    public void abrirTelaPrincipal() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}